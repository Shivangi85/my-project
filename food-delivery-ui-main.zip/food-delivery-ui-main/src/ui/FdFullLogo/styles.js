export default {
    logo_image: {
        height: '25%',
        width: '100%',
        marginBottom: '10%'
    },
};
