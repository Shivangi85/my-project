export default {
    image_container: {
        position: 'absolute',
        right: '10%',
        top: '35%',
    },
    image: {

        height: 18,
        width: 18,
    },
};
