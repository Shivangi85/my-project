export default [
    {
        title: 'Omelette',
        price: 25,
        quantity: 2,
        image: 'omelette',
    },
    {
        title: 'Beignet',
        price: 30,
        image: 'beignet',
        quantity: 2,
    },
    {
        title: 'Cornmeal mush',
        price: 10,
        image: 'cornmealMush',
        quantity: 2,
    },
];
