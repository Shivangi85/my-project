export default [
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. You have ordered omellete',
        notificationLink: 33.62,

    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty omellete is being prepared',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. You tasty omellete is out for delivery.',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty omellte has arrived',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty pizza is being prepared',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty pizza is being delivered',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty pizza is being arrive',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty burger is being prepared',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty pizza is being prepared',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty pizza is being prepared',
        notificationLink: 33.62,
    },
    {
        notifcationImg: '',
        notificationText: 'Hi Jhon. Your tasty pizza is being prepared',
        notificationLink: 33.62,
    },
];
