export const fontStyles = {
    PoppinsBold: 'Poppins-Bold',
    PoppinsRegular: 'Poppins-Regular',
};
