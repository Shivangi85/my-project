export default [
    {
        orderId: '0004512546',
        reviewRating: 4,
        reviewDatetimeDiff: '4 hours ago',
        reviewText: 'This is one of the best omellete I have had kudos to Enatega',
    },
    {
        orderId: '95842000254',
        reviewRating: 3,
        reviewDatetimeDiff: '2 days ago',
        reviewText: 'Probably the best resturant in town will keep using it',
    },
    {
        orderId: '0085462578',
        reviewRating: 5,
        reviewDatetimeDiff: '6 days ago',
        reviewText: 'Ordered another time the delivery service was great',
    },
    {
        orderId: '0085462578',
        reviewRating: 5,
        reviewDatetimeDiff: '6 days ago',
        reviewText: 'Was hungry so ordered from Enatega as always great service',
    },
    {
        orderId: '0004512546',
        reviewRating: 4,
        reviewDatetimeDiff: '4 hours ago',
        reviewText: 'This is one of the best omellete I have had kudos to Enatega',
    },
    {
        orderId: '95842000254',
        reviewRating: 3,
        reviewDatetimeDiff: '2 days ago',
        reviewText: 'Probably the best resturant in town will keep using it',
    },
    {
        orderId: '0085462578',
        reviewRating: 5,
        reviewDatetimeDiff: '6 days ago',
        reviewText: 'Ordered another time the delivery service was great',
    },
    {
        orderId: '0085462578',
        reviewRating: 5,
        reviewDatetimeDiff: '6 days ago',
        reviewText: 'Was hungry so ordered from Enatega as always great service',
    }
];
