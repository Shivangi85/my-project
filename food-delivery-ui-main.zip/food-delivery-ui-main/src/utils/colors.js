export  const colors = {
    primaryOrangeColor: "#ff550a",
    secondaryWhiteColor: 'white',
    primaryBlackColor: "#2a2a2a",
    secondaryBlackColor: '#3c3c3c',
    primaryGreenColor: '#1DB20D',
    primaryRedColor: '#fe0000',
    fontBlackColor: '#212121',
    fontGreyColor: '#949393',
    greenColor: '#11b000',
    brownishColor: '#e9e9af',
    orangeColor: '#ff8852',
    greyLinesColor: '#e1e1e1',
    lightGrayColor: '#fafafa'
}