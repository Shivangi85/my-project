export default {
    container: {
        flex: 1,
    },
};
