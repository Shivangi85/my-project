export default {
    container: {
        height: '90%',
    },
};
