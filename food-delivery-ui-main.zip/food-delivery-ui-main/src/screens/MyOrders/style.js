const Styles = {
    flex: {
        flex: 1
    },
    container: {
        height: '90%',
        width: '100%',
    },
};

export default Styles;
