const styles = {
    Flex: {
        flex: 1,
    },
    topContainer: {
        height: '20%',
    },
    botContainer: {
        flex: 1,
        marginTop: 30,
        marginBottom: 70,
    },
    item: {
        height: '10%',
        marginBottom: '4%',
    },
};

export default styles;
