import React from 'react';
import {
    View, Text
} from 'react-native';

class DebitCard extends React.Component {
    render() {
        return (
            <View>
                <Text>Placeholder Netbanking Form</Text>
          </View>
        );
    }
}


export default DebitCard;
